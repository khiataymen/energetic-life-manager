import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/constants/app_palettes.dart';
import 'core/database/local_database.dart';
import 'core/notifications/notification_service.dart';
import 'core/sync/cloud_sync_service.dart';
import 'features/calories/calories_screen.dart';
import 'features/finance/finance_screen.dart';
import 'features/language/language_srs_screen.dart';
import 'features/mechanics_quiz/mechanics_quiz_screen.dart';
import 'features/notes/notes_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.instance.init();
  await CloudSyncService.instance.ensureFirebaseInitialized();
  runApp(const EnergeticLifeApp());
}

class EnergeticLifeApp extends StatefulWidget {
  const EnergeticLifeApp({super.key});

  @override
  State<EnergeticLifeApp> createState() => _EnergeticLifeAppState();
}

class _EnergeticLifeAppState extends State<EnergeticLifeApp> {
  Locale _locale = const Locale('ar');
  ThemeMode _themeMode = ThemeMode.system;
  String _selectedPaletteId = 'blue';

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      final lang = prefs.getString('app_lang') ?? 'ar';
      _locale = Locale(lang);
      _selectedPaletteId = prefs.getString('app_palette') ?? 'blue';
      final modeStr = prefs.getString('app_theme_mode') ?? 'system';
      _themeMode = modeStr == 'dark'
          ? ThemeMode.dark
          : modeStr == 'light'
              ? ThemeMode.light
              : ThemeMode.system;
    });
  }

  Future<void> _changePalette(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('app_palette', id);
    setState(() => _selectedPaletteId = id);
  }

  Future<void> _toggleLanguage() async {
    final prefs = await SharedPreferences.getInstance();
    final next = _locale.languageCode == 'ar' ? 'en' : 'ar';
    await prefs.setString('app_lang', next);
    setState(() => _locale = Locale(next));
  }

  Future<void> _cycleThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    final nextMode = _themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    await prefs.setString('app_theme_mode', nextMode == ThemeMode.dark ? 'dark' : 'light');
    setState(() => _themeMode = nextMode);
  }

  @override
  Widget build(BuildContext context) {
    final palette = AppPalettes.palettes.firstWhere(
      (p) => p.id == _selectedPaletteId,
      orElse: () => AppPalettes.palettes.first,
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'رفيق الماستر والحياة',
      locale: _locale,
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      themeMode: _themeMode,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: palette.primary,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: palette.primary,
        brightness: Brightness.dark,
      ),
      home: MainShellScreen(
        isArabic: _locale.languageCode == 'ar',
        activePalette: palette,
        onChangePalette: _changePalette,
        onToggleLanguage: _toggleLanguage,
        onToggleTheme: _cycleThemeMode,
      ),
    );
  }
}

class MainShellScreen extends StatefulWidget {
  final bool isArabic;
  final AppPaletteOption activePalette;
  final ValueChanged<String> onChangePalette;
  final VoidCallback onToggleLanguage;
  final VoidCallback onToggleTheme;

  const MainShellScreen({
    super.key,
    required this.isArabic,
    required this.activePalette,
    required this.onChangePalette,
    required this.onToggleLanguage,
    required this.onToggleTheme,
  });

  @override
  State<MainShellScreen> createState() => _MainShellScreenState();
}

class _MainShellScreenState extends State<MainShellScreen> {
  int _currentIndex = 0;
  List<Map<String, dynamic>> _tasks = [];
  List<Map<String, dynamic>> _scheduleSlots = [];
  int _selectedDayOfWeek = 0; // 0 = Saturday (السبت)
  Map<String, double> _hoursSummary = {'study': 1.5, 'work': 1.0, 'personal': 0.5};

  // Timer State
  String _timerMode = 'pomodoro';
  String _timerCategory = 'study';
  final int _focusMinutes = 25;
  int _secondsRemaining = 25 * 60;
  int _gymElapsedSeconds = 0;
  bool _timerRunning = false;
  Timer? _ticker;

  // Routine State
  final List<int> _gymDays = [0, 2, 4];
  bool _quietHoursEnabled = true;
  final String _quietStart = '23:00';
  final String _quietEnd = '06:00';

  final List<String> _daysAr = const [
    'السبت',
    'الأحد',
    'الإثنين',
    'الثلاثاء',
    'الأربعاء',
    'الخميس',
    'الجمعة'
  ];
  final List<String> _daysEn = const [
    'Saturday',
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday'
  ];

  @override
  void initState() {
    super.initState();
    _refreshData();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  Future<void> _refreshData() async {
    final tasks = await LocalDatabase.instance.getActiveTasks();
    final slots = await LocalDatabase.instance.getScheduleForDay(_selectedDayOfWeek);
    final hrs = await LocalDatabase.instance.getHoursByCategoryLast7Days();
    if (!mounted) return;
    setState(() {
      _tasks = tasks;
      _scheduleSlots = slots;
      _hoursSummary = hrs;
    });
  }

  void _startOrPauseTimer() {
    if (_timerRunning) {
      _ticker?.cancel();
      setState(() => _timerRunning = false);
    } else {
      setState(() => _timerRunning = true);
      _ticker = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (_timerMode == 'gym') {
          setState(() => _gymElapsedSeconds++);
        } else {
          if (_secondsRemaining > 0) {
            setState(() => _secondsRemaining--);
          } else {
            timer.cancel();
            setState(() => _timerRunning = false);
            NotificationService.instance.showImmediateNotification(
              id: 901,
              title: widget.isArabic ? 'انتهت جلسة التركيز!' : 'Focus Session Complete!',
              body: widget.isArabic
                  ? 'تم تسجيل الجلسة في سجل الساعات.'
                  : 'Your focus session has been recorded.',
            );
          }
        }
      });
    }
  }

  Future<void> _finishAndLogSession() async {
    _ticker?.cancel();
    setState(() => _timerRunning = false);
    final loggedSec = _timerMode == 'gym'
        ? (_gymElapsedSeconds > 60 ? _gymElapsedSeconds : 1800)
        : (_focusMinutes * 60);
    await LocalDatabase.instance.insertTimerSession(
      mode: _timerMode,
      category: _timerCategory,
      durationSeconds: loggedSec,
    );
    await _refreshData();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(widget.isArabic
            ? '✓ تم تسجيل الساعات وتحديث إحصائيات آخر 7 أيام'
            : '✓ Session logged & 7-day summary updated'),
      ),
    );
  }

  void _showCloudSyncModal() {
    final ar = widget.isArabic;
    final user = CloudSyncService.instance.currentUser;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => AlertDialog(
          title: Text(ar ? '☁️ حساب Google والمزامنة السحابية' : '☁️ Google Sign-In & Cloud Sync'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                user != null
                    ? (ar ? 'متصل بالحساب: ${user.email}' : 'Signed in: ${user.email}')
                    : (ar
                        ? 'الحالة: يعمل محليًا (Offline-First) بدون حساب'
                        : 'Status: Working Offline-First'),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              Text(
                ar
                    ? '• عند أول تسجيل دخول يتم دمج الاتحاد (Union Merge) بالمعرّف دون فقدان بياناتك المحلية.
• حل التعارض: آخر تعديل يغلب (updatedAt + deviceId).
• التسجيلات الصوتية والمؤقت الجاري تبقى محلية.'
                    : '• First sign-in performs Union Merge by UUID.
• Conflict resolution: Last-Write-Wins (updatedAt + deviceId).',
                style: const TextStyle(fontSize: 12),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () async {
                    await CloudSyncService.instance.signInWithGoogleAndMerge();
                    await _refreshData();
                    setModalState(() {});
                  },
                  icon: const Icon(Icons.login),
                  label: Text(ar ? 'تسجيل الدخول بـ Google ومزامنة' : 'Google Sign-In & Merge'),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () async {
                    await CloudSyncService.instance.syncAllTablesBidirectional();
                    await _refreshData();
                    setModalState(() {});
                    if (ctx.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(ar ? '🔄 تمت المزامنة الآن' : '🔄 Sync completed'),
                        ),
                      );
                    }
                  },
                  icon: const Icon(Icons.sync),
                  label: Text(ar ? 'زامن الآن (Sync Now)' : 'Sync Now'),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextButton.icon(
                      onPressed: () async {
                        await CloudSyncService.instance.signOut();
                        setModalState(() {});
                      },
                      icon: const Icon(Icons.logout, size: 18),
                      label: Text(ar ? 'تسجيل الخروج' : 'Sign Out'),
                    ),
                  ),
                  Expanded(
                    child: TextButton.icon(
                      onPressed: () async {
                        await CloudSyncService.instance.deleteAllCloudDataForCurrentUser();
                        if (ctx.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(ar
                                  ? '🗑️ تم حذف بياناتك السحابية مع بقاء بيانات الهاتف'
                                  : '🗑️ Cloud data deleted; local data preserved'),
                            ),
                          );
                        }
                      },
                      icon: const Icon(Icons.delete_forever, color: Colors.redAccent, size: 18),
                      label: Text(
                        ar ? 'احذف بياناتي السحابية' : 'Delete Cloud Data',
                        style: const TextStyle(color: Colors.redAccent, fontSize: 11),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(ar ? 'إغلاق' : 'Close')),
          ],
        ),
      ),
    );
  }

  void _showPaletteModal() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.isArabic
                  ? '🎨 اختر لون الواجهة المفضل (6 ألوان متاحة)'
                  : '🎨 Choose UI Theme Palette (6 Colors)',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: AppPalettes.palettes.map((p) {
                final selected = p.id == widget.activePalette.id;
                return ChoiceChip(
                  avatar: CircleAvatar(backgroundColor: p.primary, radius: 10),
                  label: Text(widget.isArabic ? p.nameAr : p.nameEn),
                  selected: selected,
                  onSelected: (_) {
                    widget.onChangePalette(p.id);
                    Navigator.pop(ctx);
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(widget.isArabic ? 'المظهر الفاتح / الداكن:' : 'Light / Dark Mode:'),
                FilledButton.tonalIcon(
                  onPressed: () {
                    widget.onToggleTheme();
                    Navigator.pop(ctx);
                  },
                  icon: const Icon(Icons.brightness_6),
                  label: Text(widget.isArabic ? 'تبديل المظهر' : 'Toggle Theme'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showBatteryGuideDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(widget.isArabic
            ? '🔋 تجاوز قيود البطارية (شاومي / سامسونغ / هواوي)'
            : '🔋 OEM Battery Optimization Guide'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '1. Xiaomi (MIUI / HyperOS):
الإعدادات ← التطبيقات ← إدارة التطبيقات ← رفيق الماستر ← فعّل (التشغيل التلقائي Autostart) واختر في البطارية (لا توجد قيود No restrictions).
',
              ),
              const Text(
                '2. Samsung (One UI):
الإعدادات ← التطبيقات ← رفيق الماستر ← البطارية ← اختر (غير مقيد Unrestricted).
',
              ),
              const Text(
                '3. Huawei (EMUI):
الإعدادات ← البطارية ← تشغيل التطبيقات (App Launch) ← أوقف الإدارة التلقائية وفعّل الخيارات الثلاثة.',
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () =>
                    NotificationService.instance.requestIgnoreBatteryOptimizations(),
                icon: const Icon(Icons.battery_charging_full),
                label: Text(widget.isArabic
                    ? 'طلب استثناء البطارية الآن'
                    : 'Request Battery Exemption'),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () => NotificationService.instance.openExactAlarmSettings(),
                icon: const Icon(Icons.alarm_on),
                label: Text(widget.isArabic
                    ? 'تفعيل إذن المنبه الدقيق (Android 12+)'
                    : 'Allow Exact Alarms (Android 12+)'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(widget.isArabic ? 'إغلاق' : 'Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ar = widget.isArabic;
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              ar ? 'رفيق الماستر والحياة' : 'Energetic Life Manager',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            Text(
              ar ? 'نسخة كاملة • ماستر 1 ميكانيك طاقوية' : 'Complete v1.2 • M1 Energetic Mechanics',
              style: const TextStyle(fontSize: 11),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: ar ? 'حساب Google والمزامنة' : 'Google Cloud Sync',
            icon: const Icon(Icons.cloud_sync_outlined),
            onPressed: _showCloudSyncModal,
          ),
          IconButton(
            tooltip: ar ? 'تغيير ألوان الواجهة' : 'Theme Colors',
            icon: Icon(Icons.palette_outlined, color: widget.activePalette.primary),
            onPressed: _showPaletteModal,
          ),
          IconButton(
            tooltip: ar ? 'دليل البطارية والتنبيهات' : 'Battery Guide',
            icon: const Icon(Icons.battery_alert_outlined, color: Colors.amber),
            onPressed: _showBatteryGuideDialog,
          ),
          TextButton(
            onPressed: widget.onToggleLanguage,
            child: Text(ar ? 'EN' : 'عربي', style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: [
          _buildTodayTab(ar),
          _buildTimerTab(ar),
          _buildWeeklyTab(ar),
          _buildCompleteToolsHub(ar),
          _buildRoutineTab(ar),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (idx) => setState(() => _currentIndex = idx),
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.today_outlined),
            selectedIcon: const Icon(Icons.today),
            label: ar ? 'اليوم' : 'Today',
          ),
          NavigationDestination(
            icon: const Icon(Icons.timer_outlined),
            selectedIcon: const Icon(Icons.timer),
            label: ar ? 'المؤقت' : 'Timer',
          ),
          NavigationDestination(
            icon: const Icon(Icons.calendar_view_week_outlined),
            selectedIcon: const Icon(Icons.calendar_view_week),
            label: ar ? 'الأسبوع' : 'Week',
          ),
          NavigationDestination(
            icon: const Icon(Icons.handyman_outlined),
            selectedIcon: const Icon(Icons.handyman),
            label: ar ? 'أدوات (5)' : 'Tools (5)',
          ),
          NavigationDestination(
            icon: const Icon(Icons.autorenew_outlined),
            selectedIcon: const Icon(Icons.autorenew),
            label: ar ? 'الروتين' : 'Routine',
          ),
        ],
      ),
    );
  }

  // ==================== TAB 1: TODAY & TASKS ====================
  Widget _buildTodayTab(bool ar) {
    final upNextSlot = _scheduleSlots.isNotEmpty ? _scheduleSlots.first : null;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: widget.activePalette.primary,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                ar ? '⚡ القادم في جدولك الآن' : '⚡ UP NEXT TODAY',
                style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold, fontSize: 12),
              ),
              const SizedBox(height: 6),
              Text(
                upNextSlot != null
                    ? (upNextSlot['title'] as String)
                    : (ar ? 'لا توجد محاضرات أو مناوبات متبقية اليوم' : 'No remaining slots today'),
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
              ),
              if (upNextSlot != null) ...[
                const SizedBox(height: 6),
                Text(
                  '⏰ ${upNextSlot['start_time']} - ${upNextSlot['end_time']} • ${AppPalettes.categoryLabel(upNextSlot['category'] as String, ar)}',
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              ar ? '🔔 المهام والتنبيهات الدقيقة' : '🔔 Tasks & Exact Alarms',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            FilledButton.icon(
              onPressed: () => _showAddTaskDialog(ar),
              icon: const Icon(Icons.add),
              label: Text(ar ? 'مهمة جديدة' : 'Add Task'),
            ),
          ],
        ),
        const SizedBox(height: 10),
        ..._tasks.map((t) {
          final done = (t['is_completed'] as int) == 1;
          final cat = t['category'] as String;
          final catColor = AppPalettes.categoryColor(cat);
          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              leading: Checkbox(
                value: done,
                onChanged: (v) async {
                  await LocalDatabase.instance.toggleTaskCompleted(t['id'] as String, v ?? false);
                  _refreshData();
                },
              ),
              title: Text(
                t['title'] as String,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  decoration: done ? TextDecoration.lineThrough : null,
                ),
              ),
              subtitle: Row(
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: catColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      AppPalettes.categoryLabel(cat, ar),
                      style: TextStyle(color: catColor, fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    tooltip: ar ? 'غفوة 10 دقائق' : 'Snooze 10m',
                    icon: const Icon(Icons.snooze, color: Colors.amber),
                    onPressed: () async {
                      await LocalDatabase.instance.snoozeTask10Min(
                        t['id'] as String,
                        (t['reminder_at'] as int?) ?? DateTime.now().millisecondsSinceEpoch,
                      );
                      _refreshData();
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                    onPressed: () async {
                      await LocalDatabase.instance.softDeleteTask(t['id'] as String);
                      _refreshData();
                    },
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }

  void _showAddTaskDialog(bool ar) {
    final titleCtrl = TextEditingController();
    String selectedCat = 'study';
    String selectedPriority = 'high';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => AlertDialog(
          title: Text(ar ? 'إضافة مهمة مع تنبيه دقيق' : 'New Task with Exact Alarm'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleCtrl,
                decoration: InputDecoration(labelText: ar ? 'عنوان المهمة' : 'Task Title'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: selectedCat,
                items: [
                  DropdownMenuItem(value: 'study', child: Text(ar ? '📘 دراسة (ماستر)' : '📘 Study')),
                  DropdownMenuItem(value: 'work', child: Text(ar ? '💼 عمل (مقهى/خاص)' : '💼 Work')),
                  DropdownMenuItem(value: 'personal', child: Text(ar ? '🧡 شخصي وصحة' : '🧡 Personal')),
                ],
                onChanged: (v) => setModalState(() => selectedCat = v ?? 'study'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(ar ? 'إلغاء' : 'Cancel')),
            FilledButton(
              onPressed: () async {
                if (titleCtrl.text.trim().isEmpty) return;
                await LocalDatabase.instance.insertTask(
                  title: titleCtrl.text.trim(),
                  category: selectedCat,
                  priority: selectedPriority,
                  reminderAt: DateTime.now().millisecondsSinceEpoch + 3600000,
                );
                await _refreshData();
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: Text(ar ? 'حفظ وجدولة' : 'Save & Schedule'),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== TAB 2: TIMER ====================
  Widget _buildTimerTab(bool ar) {
    final displaySec = _timerMode == 'gym' ? _gymElapsedSeconds : _secondsRemaining;
    final mm = (displaySec ~/ 60).toString().padLeft(2, '0');
    final ss = (displaySec % 60).toString().padLeft(2, '0');

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SegmentedButton<String>(
          segments: [
            ButtonSegment(value: 'pomodoro', label: Text(ar ? '🍅 بومودورو' : '🍅 Pomodoro')),
            ButtonSegment(value: 'custom', label: Text(ar ? '⏱️ مخصص' : '⏱️ Custom')),
            ButtonSegment(value: 'gym', label: Text(ar ? '🏋️ جيم (تصاعدي)' : '🏋️ Gym Up')),
          ],
          selected: {_timerMode},
          onSelectionChanged: (s) {
            _ticker?.cancel();
            setState(() {
              _timerRunning = false;
              _timerMode = s.first;
              _secondsRemaining = _focusMinutes * 60;
              _gymElapsedSeconds = 0;
            });
          },
        ),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 16),
            child: Column(
              children: [
                DropdownButton<String>(
                  value: _timerCategory,
                  items: [
                    DropdownMenuItem(value: 'study', child: Text(ar ? '📘 دراسة (ماستر)' : '📘 Study')),
                    DropdownMenuItem(value: 'work', child: Text(ar ? '💼 عمل (مقهى الإنترنت)' : '💼 Work')),
                    DropdownMenuItem(value: 'personal', child: Text(ar ? '🧡 شخصي وصحة (جيم)' : '🧡 Personal & Gym')),
                  ],
                  onChanged: (v) => setState(() => _timerCategory = v ?? 'study'),
                ),
                const SizedBox(height: 12),
                Text(
                  '$mm:$ss',
                  style: const TextStyle(fontSize: 64, fontWeight: FontWeight.w900, fontFamily: 'monospace'),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 12,
                  children: [
                    FilledButton.icon(
                      onPressed: _startOrPauseTimer,
                      icon: Icon(_timerRunning ? Icons.pause : Icons.play_arrow),
                      label: Text(_timerRunning
                          ? (ar ? 'إيقاف مؤقت' : 'Pause')
                          : (ar ? 'ابدأ الجلسة' : 'Start')),
                    ),
                    FilledButton.tonalIcon(
                      onPressed: _finishAndLogSession,
                      icon: const Icon(Icons.check_circle_outline),
                      label: Text(ar ? 'إنهاء وتسجيل الساعات' : 'Finish & Log'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ar ? '📊 ملخص الساعات حسب التصنيف (آخر 7 أيام)' : '📊 Hours Summary (Last 7 Days)',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                ),
                const SizedBox(height: 12),
                _buildHoursRow(ar ? '📘 دراسة (ماستر)' : '📘 Study', _hoursSummary['study'] ?? 0, AppPalettes.studyBlue),
                _buildHoursRow(ar ? '💼 عمل (مقهى/خاص)' : '💼 Work', _hoursSummary['work'] ?? 0, AppPalettes.workGreen),
                _buildHoursRow(ar ? '🧡 شخصي وجيم' : '🧡 Personal & Gym', _hoursSummary['personal'] ?? 0, AppPalettes.personalOrange),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHoursRow(String label, double hours, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
          Text('${hours.toStringAsFixed(1)} h', style: TextStyle(fontWeight: FontWeight.bold, color: color)),
        ],
      ),
    );
  }

  // ==================== TAB 3: WEEKLY SCHEDULE ====================
  Widget _buildWeeklyTab(bool ar) {
    final labels = ar ? _daysAr : _daysEn;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: List.generate(7, (idx) {
              final selected = idx == _selectedDayOfWeek;
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ChoiceChip(
                  label: Text(labels[idx]),
                  selected: selected,
                  onSelected: (_) {
                    setState(() => _selectedDayOfWeek = idx);
                    _refreshData();
                  },
                ),
              );
            }),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              ar ? 'فترات يوم ${labels[_selectedDayOfWeek]}' : '${labels[_selectedDayOfWeek]} Slots',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            FilledButton.icon(
              onPressed: () => _showAddScheduleSlotDialog(ar),
              icon: const Icon(Icons.add),
              label: Text(ar ? 'إضافة فترة' : 'Add Slot'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ..._scheduleSlots.map((s) {
          final cat = s['category'] as String;
          final color = AppPalettes.categoryColor(cat);
          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: color.withOpacity(0.15),
                child: Icon(Icons.schedule, color: color),
              ),
              title: Text(s['title'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${s['start_time']} - ${s['end_time']} • ${AppPalettes.categoryLabel(cat, ar)}'),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                onPressed: () async {
                  await LocalDatabase.instance.softDeleteScheduleSlot(s['id'] as String);
                  _refreshData();
                },
              ),
            ),
          );
        }),
      ],
    );
  }

  void _showAddScheduleSlotDialog(bool ar) {
    final titleCtrl = TextEditingController();
    final startCtrl = TextEditingController(text: '08:30');
    final endCtrl = TextEditingController(text: '10:00');
    String cat = 'study';

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ar ? 'إضافة فترة أسبوعية' : 'Add Weekly Slot'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleCtrl,
              decoration: InputDecoration(labelText: ar ? 'عنوان الفترة' : 'Slot Title'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: startCtrl,
              decoration: InputDecoration(labelText: ar ? 'وقت البداية (08:30)' : 'Start (08:30)'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: endCtrl,
              decoration: InputDecoration(labelText: ar ? 'وقت النهاية (10:00)' : 'End (10:00)'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(ar ? 'إلغاء' : 'Cancel')),
          FilledButton(
            onPressed: () async {
              if (titleCtrl.text.trim().isEmpty) return;
              await LocalDatabase.instance.insertScheduleSlot(
                title: titleCtrl.text.trim(),
                category: cat,
                dayOfWeek: _selectedDayOfWeek,
                startTime: startCtrl.text.trim(),
                endTime: endCtrl.text.trim(),
              );
              await _refreshData();
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: Text(ar ? 'حفظ' : 'Save'),
          ),
        ],
      ),
    );
  }

  // ==================== TAB 4: COMPLETE 5 TOOLS HUB ====================
  Widget _buildCompleteToolsHub(bool ar) {
    return DefaultTabController(
      length: 5,
      child: Column(
        children: [
          TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: ar ? '⚙️ الميكانيك (40)' : '⚙️ Mechanics (40)'),
              Tab(text: ar ? '💰 المالية (دج)' : '💰 Finance (DZD)'),
              Tab(text: ar ? '🎙️ المذكرات' : '🎙️ Notes'),
              Tab(text: ar ? '🍲 السعرات والأكل' : '🍲 Calories'),
              Tab(text: ar ? '🇬🇧 الإنجليزية (SRS)' : '🇬🇧 Language SRS'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                MechanicsQuizScreen(isArabic: ar),
                FinanceScreen(isArabic: ar),
                NotesScreen(isArabic: ar),
                CaloriesScreen(isArabic: ar),
                LanguageSrsScreen(isArabic: ar),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==================== TAB 5: ROUTINE & QUIET HOURS ====================
  Widget _buildRoutineTab(bool ar) {
    final labels = ar ? _daysAr : _daysEn;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ar ? '🍽️ تذكير أوقات الوجبات الأربع' : '🍽️ 4 Daily Meals Reminders',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                const SizedBox(height: 8),
                const ListTile(title: Text('الفطور الصباحي'), trailing: Text('07:15')),
                const ListTile(title: Text('وجبة الغداء'), trailing: Text('12:45')),
                const ListTile(title: Text('لمجة المساء'), trailing: Text('17:00')),
                const ListTile(title: Text('وجبة العشاء'), trailing: Text('21:30')),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ar ? '🏋️ أيام الجيم (اختر 3 أيام أسبوعيًا)' : '🏋️ Gym Days (Pick 3 Days/Week)',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  children: List.generate(7, (idx) {
                    final selected = _gymDays.contains(idx);
                    return FilterChip(
                      label: Text(labels[idx]),
                      selected: selected,
                      onSelected: (v) {
                        setState(() {
                          if (v && _gymDays.length < 3) {
                            _gymDays.add(idx);
                          } else if (!v) {
                            _gymDays.remove(idx);
                          }
                        });
                      },
                    );
                  }),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: SwitchListTile(
            title: Text(ar ? '🌙 ساعات الهدوء ($_quietStart - $_quietEnd)' : '🌙 Quiet Hours ($_quietStart - $_quietEnd)'),
            subtitle: Text(ar
                ? 'تُسكت تنبيهات الروتين دون إيقاف تنبيهات المهام والمؤقت'
                : 'Silences routine alerts while keeping tasks & timer active'),
            value: _quietHoursEnabled,
            onChanged: (v) => setState(() => _quietHoursEnabled = v),
          ),
        ),
      ],
    );
  }
}
