import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../database/local_database.dart';

enum SyncState { offlineOnly, syncing, synced, error }

class CloudSyncService {
  static final CloudSyncService instance = CloudSyncService._();
  CloudSyncService._();

  bool _firebaseInitialized = false;
  SyncState state = SyncState.offlineOnly;
  String? lastSyncError;

  Future<bool> ensureFirebaseInitialized() async {
    if (_firebaseInitialized) return true;
    try {
      await Firebase.initializeApp();
      FirebaseFirestore.instance.settings = const Settings(
        persistenceEnabled: true,
        cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
      );
      _firebaseInitialized = true;
      return true;
    } catch (e) {
      lastSyncError =
          'Firebase awaits google-services.json configuration. App runs 100% offline-first.';
      return false;
    }
  }

  User? get currentUser {
    if (!_firebaseInitialized) return null;
    return FirebaseAuth.instance.currentUser;
  }

  /// Sign in with Google Account and automatically trigger Union Merge by ID
  Future<User?> signInWithGoogleAndMerge() async {
    final ready = await ensureFirebaseInitialized();
    if (!ready) return null;

    final googleUser = await GoogleSignIn().signIn();
    if (googleUser == null) return null;

    final googleAuth = await googleUser.authentication;
    final cred = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    final userCred = await FirebaseAuth.instance.signInWithCredential(cred);
    if (userCred.user != null) {
      await syncAllTablesBidirectional();
    }
    return userCred.user;
  }

  /// Two-Way Sync with Union Merge by ID & Last-Write-Wins (updatedAt + deviceId) + Tombstone
  Future<void> syncAllTablesBidirectional() async {
    final ready = await ensureFirebaseInitialized();
    if (!ready || currentUser == null) return;

    state = SyncState.syncing;
    final uid = currentUser!.uid;
    final userDoc = FirebaseFirestore.instance.collection('users').doc(uid);

    try {
      for (final table in LocalDatabase.syncableTables) {
        final colRef = userDoc.collection(table);

        // Step 1: Pull all remote documents in collection and apply Union Merge / LWW locally
        final remoteSnap = await colRef.get();
        final Map<String, Map<String, dynamic>> remoteMap = {};
        for (final doc in remoteSnap.docs) {
          final data = doc.data();
          remoteMap[doc.id] = data;
          await LocalDatabase.instance.upsertRemoteRow(table: table, remoteData: data);
        }

        // Step 2: Push local rows that are missing remotely or newer locally
        final localRows = await LocalDatabase.instance.getAllRowsForTable(table);
        final batch = FirebaseFirestore.instance.batch();
        int batchCount = 0;

        for (final localRow in localRows) {
          final id = localRow['id'] as String;
          final localUpdated = (localRow['updated_at'] as int?) ?? 0;
          final localDev = (localRow['device_id'] as String?) ?? '';

          final remoteRow = remoteMap[id];
          final remoteUpdated = (remoteRow?['updated_at'] as int?) ?? -1;
          final remoteDev = (remoteRow?['device_id'] as String?) ?? '';

          final localWins = remoteRow == null ||
              (localUpdated > remoteUpdated) ||
              (localUpdated == remoteUpdated && localDev.compareTo(remoteDev) >= 0);

          if (localWins) {
            final payload = Map<String, dynamic>.from(localRow);
            payload.remove('sync_status');
            // Never upload local voice audio files to Firestore
            if (table == 'notes') {
              payload.remove('local_audio_path');
            }
            batch.set(colRef.doc(id), payload, SetOptions(merge: true));
            batchCount++;
            await LocalDatabase.instance.markRowSynced(table, id);
          }
        }

        if (batchCount > 0) {
          await batch.commit();
        }
      }
      state = SyncState.synced;
      lastSyncError = null;
    } catch (e) {
      state = SyncState.error;
      lastSyncError = e.toString();
    }
  }

  Future<void> signOut() async {
    if (!_firebaseInitialized) return;
    await GoogleSignIn().signOut();
    await FirebaseAuth.instance.signOut();
    state = SyncState.offlineOnly;
  }

  /// Delete all cloud documents under users/{uid}/... while keeping local SQLite intact
  Future<void> deleteAllCloudDataForCurrentUser() async {
    final ready = await ensureFirebaseInitialized();
    if (!ready || currentUser == null) return;

    final uid = currentUser!.uid;
    final userDoc = FirebaseFirestore.instance.collection('users').doc(uid);

    for (final table in LocalDatabase.syncableTables) {
      final snap = await userDoc.collection(table).get();
      final batch = FirebaseFirestore.instance.batch();
      for (final d in snap.docs) {
        batch.delete(d.reference);
      }
      if (snap.docs.isNotEmpty) {
        await batch.commit();
      }
    }
    await userDoc.delete();
  }
}
