import 'package:flutter/material.dart';
import '../../core/database/local_database.dart';

class FinanceScreen extends StatefulWidget {
  final bool isArabic;

  const FinanceScreen({super.key, required this.isArabic});

  @override
  State<FinanceScreen> createState() => _FinanceScreenState();
}

class _FinanceScreenState extends State<FinanceScreen> {
  late int _year;
  late int _month;
  List<Map<String, dynamic>> _transactions = [];

  final List<String> _categories = const [
    'عمل مقهى الإنترنت',
    'خدمات رقمية خاصة',
    'طعام وقهوة',
    'نقل وجامعة',
    'رياضة وصحة',
    'أخرى',
  ];

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _year = now.year;
    _month = now.month;
    _loadTransactions();
  }

  String get _monthKey => '$_year-${_month.toString().padLeft(2, '0')}';

  Future<void> _loadTransactions() async {
    final rows = await LocalDatabase.instance.getFinanceTransactionsByMonth(_monthKey);
    if (!mounted) return;
    setState(() => _transactions = rows);
  }

  void _changeMonth(int delta) {
    setState(() {
      _month += delta;
      if (_month > 12) {
        _month = 1;
        _year++;
      } else if (_month < 1) {
        _month = 12;
        _year--;
      }
    });
    _loadTransactions();
  }

  void _showAddTransactionModal() {
    final ar = widget.isArabic;
    String txType = 'expense';
    String selectedCat = _categories[2];
    final amountCtrl = TextEditingController();
    final noteCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => AlertDialog(
          title: Text(ar ? '💰 تسجيل عملية مالية (دج)' : '💰 Add Transaction (DZD)'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SegmentedButton<String>(
                  segments: [
                    ButtonSegment(value: 'income', label: Text(ar ? '➕ دخل' : '➕ Income')),
                    ButtonSegment(value: 'expense', label: Text(ar ? '➖ مصروف' : '➖ Expense')),
                  ],
                  selected: {txType},
                  onSelectionChanged: (s) => setModalState(() => txType = s.first),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: amountCtrl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(
                    labelText: ar ? 'المبلغ بالدينار الجزائري (دج)' : 'Amount (DZD)',
                    suffixText: 'DZD',
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: selectedCat,
                  items: _categories
                      .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                      .toList(),
                  onChanged: (v) => setModalState(() => selectedCat = v ?? _categories.first),
                  decoration: InputDecoration(labelText: ar ? 'الفئة' : 'Category'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: noteCtrl,
                  decoration: InputDecoration(labelText: ar ? 'ملاحظة (اختياري)' : 'Note'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(ar ? 'إلغاء' : 'Cancel')),
            FilledButton(
              onPressed: () async {
                final val = double.tryParse(amountCtrl.text.trim()) ?? 0;
                if (val <= 0) return;
                await LocalDatabase.instance.insertFinanceTransaction(
                  txType: txType,
                  amountDzd: val,
                  subCategory: selectedCat,
                  note: noteCtrl.text.trim(),
                  txDay: DateTime.now().day,
                  monthKey: _monthKey,
                );
                await _loadTransactions();
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: Text(ar ? 'حفظ' : 'Save'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ar = widget.isArabic;
    double totalIncome = 0;
    double totalExpense = 0;
    final Map<String, double> expenseByCat = {};
    final Map<int, double> netByDay = {};

    for (final t in _transactions) {
      final amt = (t['amount_dzd'] as num).toDouble();
      final isInc = t['tx_type'] == 'income';
      final cat = t['sub_category'] as String;
      final day = t['tx_day'] as int;

      if (isInc) {
        totalIncome += amt;
        netByDay[day] = (netByDay[day] ?? 0) + amt;
      } else {
        totalExpense += amt;
        expenseByCat[cat] = (expenseByCat[cat] ?? 0) + amt;
        netByDay[day] = (netByDay[day] ?? 0) - amt;
      }
    }
    final netBalance = totalIncome - totalExpense;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Month Switcher Header
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton.outlined(
              onPressed: () => _changeMonth(-1),
              icon: const Icon(Icons.chevron_left),
            ),
            Text(
              ar ? '📅 شهر $_monthKey' : '📅 Month $_monthKey',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
            ),
            IconButton.outlined(
              onPressed: () => _changeMonth(1),
              icon: const Icon(Icons.chevron_right),
            ),
            FilledButton.icon(
              onPressed: _showAddTransactionModal,
              icon: const Icon(Icons.add),
              label: Text(ar ? 'عملية (دج)' : 'Add DZD'),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // 3 Summary Cards (Income, Expense, Monthly Net Balance in DZD)
        Row(
          children: [
            Expanded(
              child: _buildSummaryCard(
                ar ? 'الدخل' : 'Income',
                '${totalIncome.toStringAsFixed(0)} دج',
                Colors.green,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _buildSummaryCard(
                ar ? 'المصروف' : 'Expense',
                '${totalExpense.toStringAsFixed(0)} دج',
                Colors.redAccent,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _buildSummaryCard(
                ar ? 'الرصيد الشهري' : 'Net Balance',
                '${netBalance.toStringAsFixed(0)} دج',
                netBalance >= 0 ? Colors.blueAccent : Colors.orange,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        // Chart 1: Expenses Breakdown by Category
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ar ? '📊 الرسم البياني للمصاريف بحسب الفئة (دج)' : '📊 Expenses by Category (DZD)',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                const SizedBox(height: 10),
                if (expenseByCat.isEmpty)
                  Text(ar ? 'لا توجد مصاريف مسجلة في هذا الشهر.' : 'No expenses this month.')
                else
                  ...expenseByCat.entries.map((e) {
                    final pct = totalExpense > 0 ? (e.value / totalExpense) : 0.0;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(e.key, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                              Text(
                                '${e.value.toStringAsFixed(0)} دج (${(pct * 100).toStringAsFixed(0)}%)',
                                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          LinearProgressIndicator(
                            value: pct,
                            minHeight: 8,
                            borderRadius: BorderRadius.circular(6),
                            color: Colors.deepOrangeAccent,
                          ),
                        ],
                      ),
                    );
                  }),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),

        // Chart 2: Daily Flow Bar Chart
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ar ? '📈 الحركة المالية بحسب اليوم' : '📈 Daily Cashflow',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: netByDay.entries.map((entry) {
                    final positive = entry.value >= 0;
                    return Chip(
                      backgroundColor: positive
                          ? Colors.green.withOpacity(0.15)
                          : Colors.red.withOpacity(0.15),
                      label: Text(
                        '${ar ? "يوم" : "D"} ${entry.key}: ${positive ? "+" : ""}${entry.value.toStringAsFixed(0)} دج',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: positive ? Colors.green : Colors.redAccent,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),

        // Transactions List
        Text(
          ar ? 'سجل العمليات الشهرية' : 'Monthly Transactions',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
        ),
        const SizedBox(height: 8),
        ..._transactions.map((t) {
          final isInc = t['tx_type'] == 'income';
          final amt = (t['amount_dzd'] as num).toDouble();
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor:
                    isInc ? Colors.green.withOpacity(0.15) : Colors.red.withOpacity(0.15),
                child: Icon(
                  isInc ? Icons.arrow_downward : Icons.arrow_upward,
                  color: isInc ? Colors.green : Colors.redAccent,
                ),
              ),
              title: Text(
                t['sub_category'] as String,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text('${t['note']} • ${ar ? "يوم" : "Day"} ${t['tx_day']}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '${isInc ? "+" : "-"}${amt.toStringAsFixed(0)} دج',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      color: isInc ? Colors.green : Colors.redAccent,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, size: 20),
                    onPressed: () async {
                      await LocalDatabase.instance.softDeleteFinanceTransaction(t['id'] as String);
                      _loadTransactions();
                    },
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildSummaryCard(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Column(
        children: [
          Text(label, style: const TextStyle(fontSize: 11)),
          const SizedBox(height: 4),
          FittedBox(
            child: Text(
              value,
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: color),
            ),
          ),
        ],
      ),
    );
  }
}
