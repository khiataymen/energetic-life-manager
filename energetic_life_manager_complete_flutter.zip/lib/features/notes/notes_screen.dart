import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import '../../core/database/local_database.dart';

class NotesScreen extends StatefulWidget {
  final bool isArabic;

  const NotesScreen({super.key, required this.isArabic});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  final TextEditingController _searchCtrl = TextEditingController();
  final AudioRecorder _audioRecorder = AudioRecorder();
  final AudioPlayer _audioPlayer = AudioPlayer();

  List<Map<String, dynamic>> _notes = [];
  bool _isRecording = false;
  DateTime? _recordingStartedAt;
  String? _playingNoteId;

  @override
  void initState() {
    super.initState();
    _loadNotes();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _audioRecorder.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _loadNotes() async {
    final rows = await LocalDatabase.instance.getNotes(searchQuery: _searchCtrl.text);
    if (!mounted) return;
    setState(() => _notes = rows);
  }

  Future<void> _toggleVoiceRecording() async {
    final ar = widget.isArabic;
    if (_isRecording) {
      final path = await _audioRecorder.stop();
      final durationSec = _recordingStartedAt != null
          ? DateTime.now().difference(_recordingStartedAt!).inSeconds
          : 0;
      setState(() => _isRecording = false);

      if (path != null) {
        final nowStr =
            '${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}';
        await LocalDatabase.instance.insertNote(
          title: ar ? 'مذكرة صوتية ($nowStr)' : 'Voice Note ($nowStr)',
          content: ar
              ? 'تسجيل صوتي محفوظ محليًا على الهاتف (لا يُرفع إلى السحابة)'
              : 'Local voice recording saved on device (excluded from cloud sync)',
          noteType: 'voice',
          localAudioPath: path,
          audioDurationSec: durationSec > 0 ? durationSec : 1,
        );
        await _loadNotes();
      }
    } else {
      final hasPerm = await _audioRecorder.hasPermission();
      if (!hasPerm) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(ar
                ? 'يرجى منح إذن الميكروفون لتسجيل المذكرات الصوتية'
                : 'Please grant microphone permission to record voice notes'),
          ),
        );
        return;
      }
      final dir = await getApplicationDocumentsDirectory();
      final filePath =
          '${dir.path}/voice_note_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _audioRecorder.start(const RecordConfig(), path: filePath);
      setState(() {
        _isRecording = true;
        _recordingStartedAt = DateTime.now();
      });
    }
  }

  Future<void> _playVoiceNote(Map<String, dynamic> note) async {
    final id = note['id'] as String;
    final path = note['local_audio_path'] as String?;
    if (path == null || !File(path).existsSync()) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(widget.isArabic
              ? 'الملف الصوتي محفوظ على الجهاز الأصلي فقط'
              : 'Audio file exists only on the recording device'),
        ),
      );
      return;
    }

    if (_playingNoteId == id) {
      await _audioPlayer.stop();
      setState(() => _playingNoteId = null);
    } else {
      setState(() => _playingNoteId = id);
      await _audioPlayer.play(DeviceFileSource(path));
      _audioPlayer.onPlayerComplete.first.then((_) {
        if (mounted) setState(() => _playingNoteId = null);
      });
    }
  }

  void _showAddTextNoteDialog() {
    final ar = widget.isArabic;
    final titleCtrl = TextEditingController();
    final contentCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ar ? '📝 مذكرة نصية جديدة (تُزامن سحابيًا)' : '📝 New Text Note (Cloud Synced)'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleCtrl,
              decoration: InputDecoration(labelText: ar ? 'العنوان' : 'Title'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: contentCtrl,
              maxLines: 4,
              decoration: InputDecoration(labelText: ar ? 'محتوى المذكرة' : 'Note Content'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(ar ? 'إلغاء' : 'Cancel')),
          FilledButton(
            onPressed: () async {
              if (titleCtrl.text.trim().isEmpty) return;
              await LocalDatabase.instance.insertNote(
                title: titleCtrl.text.trim(),
                content: contentCtrl.text.trim(),
                noteType: 'text',
              );
              await _loadNotes();
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: Text(ar ? 'حفظ' : 'Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ar = widget.isArabic;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (_) => _loadNotes(),
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: ar ? 'ابحث في المذكرات النصية والصوتية...' : 'Search text & voice notes...',
                    isDense: true,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton.icon(
                onPressed: _showAddTextNoteDialog,
                icon: const Icon(Icons.note_add_outlined),
                label: Text(ar ? 'نص' : 'Text'),
              ),
              const SizedBox(width: 6),
              FilledButton.tonalIcon(
                style: FilledButton.styleFrom(
                  backgroundColor: _isRecording ? Colors.red.withOpacity(0.2) : null,
                  foregroundColor: _isRecording ? Colors.red : null,
                ),
                onPressed: _toggleVoiceRecording,
                icon: Icon(_isRecording ? Icons.stop_circle : Icons.mic),
                label: Text(_isRecording ? (ar ? 'إيقاف' : 'Stop') : (ar ? 'صوت' : 'Voice')),
              ),
            ],
          ),
        ),
        Expanded(
          child: _notes.isEmpty
              ? Center(
                  child: Text(ar ? 'لا توجد مذكرات مطابقة للبحث' : 'No matching notes'),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  itemCount: _notes.length,
                  itemBuilder: (ctx, i) {
                    final n = _notes[i];
                    final isVoice = n['note_type'] == 'voice';
                    final isPlaying = _playingNoteId == n['id'];
                    final dur = n['audio_duration_sec'] as int? ?? 0;

                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: isVoice
                              ? Colors.redAccent.withOpacity(0.15)
                              : Colors.blueAccent.withOpacity(0.15),
                          child: Icon(
                            isVoice ? Icons.mic : Icons.description_outlined,
                            color: isVoice ? Colors.redAccent : Colors.blueAccent,
                          ),
                        ),
                        title: Row(
                          children: [
                            Expanded(
                              child: Text(
                                n['title'] as String,
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.grey.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                isVoice
                                    ? (ar ? 'محلي فقط (${dur}ث)' : 'Local Audio (${dur}s)')
                                    : (ar ? 'يُزامن سحابيًا' : 'Cloud Synced'),
                                style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(n['content'] as String),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (isVoice)
                              IconButton(
                                icon: Icon(
                                  isPlaying ? Icons.stop : Icons.play_arrow,
                                  color: Colors.green,
                                ),
                                onPressed: () => _playVoiceNote(n),
                              ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                              onPressed: () async {
                                await LocalDatabase.instance.softDeleteNote(n['id'] as String);
                                _loadNotes();
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
