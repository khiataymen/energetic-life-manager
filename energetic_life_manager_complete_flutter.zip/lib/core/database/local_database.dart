import 'package:path/path.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

class LocalDatabase {
  static final LocalDatabase instance = LocalDatabase._init();
  static Database? _database;
  static const _uuid = Uuid();

  LocalDatabase._init();

  static const List<String> syncableTables = [
    'tasks',
    'timer_sessions',
    'weekly_schedule',
    'notes',
    'finance_transactions',
    'mechanics_progress',
    'food_logs',
    'vocab_cards',
  ];

  Future<String> getDeviceId() async {
    final prefs = await SharedPreferences.getInstance();
    String? devId = prefs.getString('unique_device_id');
    if (devId == null) {
      devId = 'android_${_uuid.v4().substring(0, 8)}';
      await prefs.setString('unique_device_id', devId);
    }
    return devId;
  }

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('energetic_life_complete.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 3,
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE tasks (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        priority TEXT NOT NULL,
        reminder_at INTEGER,
        is_completed INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        sync_status INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE timer_sessions (
        id TEXT PRIMARY KEY,
        mode TEXT NOT NULL,
        category TEXT NOT NULL,
        duration_seconds INTEGER NOT NULL,
        date_key TEXT NOT NULL,
        updated_at INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        sync_status INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE weekly_schedule (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        day_of_week INTEGER NOT NULL,
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        notify_on_start INTEGER NOT NULL DEFAULT 1,
        updated_at INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        sync_status INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE notes (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        note_type TEXT NOT NULL,
        local_audio_path TEXT,
        audio_duration_sec INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        sync_status INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE finance_transactions (
        id TEXT PRIMARY KEY,
        tx_type TEXT NOT NULL,
        amount_dzd REAL NOT NULL,
        sub_category TEXT NOT NULL,
        note TEXT NOT NULL,
        tx_day INTEGER NOT NULL,
        month_key TEXT NOT NULL,
        updated_at INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        sync_status INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE mechanics_progress (
        id TEXT PRIMARY KEY,
        question_id INTEGER NOT NULL UNIQUE,
        difficulty_weight INTEGER NOT NULL DEFAULT 1,
        times_reviewed INTEGER NOT NULL DEFAULT 0,
        times_known INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        sync_status INTEGER NOT NULL DEFAULT 1
      )
    ''');

    // Phase C Table 7: Food Logs (Calorie Counter & Algerian Foods)
    await db.execute('''
      CREATE TABLE food_logs (
        id TEXT PRIMARY KEY,
        food_name TEXT NOT NULL,
        calories INTEGER NOT NULL,
        grams INTEGER NOT NULL DEFAULT 100,
        date_key TEXT NOT NULL,
        updated_at INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        sync_status INTEGER NOT NULL DEFAULT 1
      )
    ''');

    // Phase C Table 8: Vocabulary Cards (Spaced Repetition 1, 2, 4, 8, 16, 32 days)
    await db.execute('''
      CREATE TABLE vocab_cards (
        id TEXT PRIMARY KEY,
        word TEXT NOT NULL,
        meaning TEXT NOT NULL,
        language_code TEXT NOT NULL DEFAULT 'en-US',
        interval_days INTEGER NOT NULL DEFAULT 1,
        next_review_ms INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        sync_status INTEGER NOT NULL DEFAULT 1
      )
    ''');

    final now = DateTime.now();
    final nowMs = now.millisecondsSinceEpoch;
    final todayKey =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    final monthKey = '${now.year}-${now.month.toString().padLeft(2, '0')}';

    // Seed initial data
    await db.insert('tasks', {
      'id': _uuid.v4(),
      'title': 'حل سلسلة أعمال موجهة TD انتقال الحرارة بالتوصيل (Conduction)',
      'category': 'study',
      'priority': 'high',
      'reminder_at': nowMs + 3600000,
      'is_completed': 0,
      'updated_at': nowMs,
      'device_id': 'seed_device',
      'is_deleted': 0,
      'sync_status': 1,
    });

    await db.insert('weekly_schedule', {
      'id': _uuid.v4(),
      'title': 'محاضرة ثرموديناميك متقدم (مدرج B)',
      'category': 'study',
      'day_of_week': 0,
      'start_time': '08:30',
      'end_time': '10:00',
      'notify_on_start': 1,
      'updated_at': nowMs,
      'device_id': 'seed_device',
      'is_deleted': 0,
      'sync_status': 1,
    });

    await db.insert('finance_transactions', {
      'id': _uuid.v4(),
      'tx_type': 'income',
      'amount_dzd': 18000.0,
      'sub_category': 'عمل مقهى الإنترنت',
      'note': 'راتب نصف شهري',
      'tx_day': 5,
      'month_key': monthKey,
      'updated_at': nowMs,
      'device_id': 'seed_device',
      'is_deleted': 0,
      'sync_status': 1,
    });

    await db.insert('food_logs', {
      'id': _uuid.v4(),
      'food_name': 'كسكس باللحم والخضر (صحن متوسط)',
      'calories': 620,
      'grams': 350,
      'date_key': todayKey,
      'updated_at': nowMs,
      'device_id': 'seed_device',
      'is_deleted': 0,
      'sync_status': 1,
    });

    // Seed English technical & daily vocabulary cards
    final initialVocab = [
      {'w': 'Heat Exchanger', 'm': 'مبادل حراري', 'd': 2},
      {'w': 'Boundary Layer', 'm': 'الطبقة الحدية في الجريان', 'd': 4},
      {'w': 'Thermal Efficiency', 'm': 'المردود الحراري / الكفاءة الحرارية', 'd': 1},
      {'w': 'Resilience', 'm': 'المرونة والقدرة على التحمل', 'd': 8},
      {'w': 'Nozzle', 'm': 'فوهة متقاربة/متباعدة', 'd': 16},
    ];
    for (final item in initialVocab) {
      await db.insert('vocab_cards', {
        'id': _uuid.v4(),
        'word': item['w'],
        'meaning': item['m'],
        'language_code': 'en-US',
        'interval_days': item['d'],
        'next_review_ms': nowMs,
        'updated_at': nowMs,
        'device_id': 'seed_device',
        'is_deleted': 0,
        'sync_status': 1,
      });
    }
  }

  // ==================== TASKS ====================
  Future<List<Map<String, dynamic>>> getActiveTasks() async {
    final db = await database;
    return db.query('tasks', where: 'is_deleted = 0', orderBy: 'is_completed ASC, updated_at DESC');
  }

  Future<void> insertTask({
    required String title,
    required String category,
    required String priority,
    required int? reminderAt,
  }) async {
    final db = await database;
    final devId = await getDeviceId();
    await db.insert('tasks', {
      'id': _uuid.v4(),
      'title': title,
      'category': category,
      'priority': priority,
      'reminder_at': reminderAt,
      'is_completed': 0,
      'updated_at': DateTime.now().millisecondsSinceEpoch,
      'device_id': devId,
      'is_deleted': 0,
      'sync_status': 1,
    });
  }

  Future<void> toggleTaskCompleted(String id, bool completed) async {
    final db = await database;
    final devId = await getDeviceId();
    await db.update(
      'tasks',
      {
        'is_completed': completed ? 1 : 0,
        'updated_at': DateTime.now().millisecondsSinceEpoch,
        'device_id': devId,
        'sync_status': 1,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> snoozeTask10Min(String id, int currentReminderMs) async {
    final db = await database;
    final devId = await getDeviceId();
    final base = currentReminderMs > DateTime.now().millisecondsSinceEpoch
        ? currentReminderMs
        : DateTime.now().millisecondsSinceEpoch;
    await db.update(
      'tasks',
      {
        'reminder_at': base + (10 * 60 * 1000),
        'updated_at': DateTime.now().millisecondsSinceEpoch,
        'device_id': devId,
        'sync_status': 1,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> softDeleteTask(String id) async {
    final db = await database;
    final devId = await getDeviceId();
    await db.update(
      'tasks',
      {
        'is_deleted': 1,
        'updated_at': DateTime.now().millisecondsSinceEpoch,
        'device_id': devId,
        'sync_status': 1,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // ==================== SCHEDULE ====================
  Future<List<Map<String, dynamic>>> getScheduleForDay(int dayOfWeek) async {
    final db = await database;
    return db.query(
      'weekly_schedule',
      where: 'is_deleted = 0 AND day_of_week = ?',
      whereArgs: [dayOfWeek],
      orderBy: 'start_time ASC',
    );
  }

  Future<void> insertScheduleSlot({
    required String title,
    required String category,
    required int dayOfWeek,
    required String startTime,
    required String endTime,
  }) async {
    final db = await database;
    final devId = await getDeviceId();
    await db.insert('weekly_schedule', {
      'id': _uuid.v4(),
      'title': title,
      'category': category,
      'day_of_week': dayOfWeek,
      'start_time': startTime,
      'end_time': endTime,
      'notify_on_start': 1,
      'updated_at': DateTime.now().millisecondsSinceEpoch,
      'device_id': devId,
      'is_deleted': 0,
      'sync_status': 1,
    });
  }

  Future<void> softDeleteScheduleSlot(String id) async {
    final db = await database;
    final devId = await getDeviceId();
    await db.update(
      'weekly_schedule',
      {
        'is_deleted': 1,
        'updated_at': DateTime.now().millisecondsSinceEpoch,
        'device_id': devId,
        'sync_status': 1,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // ==================== TIMER SESSIONS ====================
  Future<void> insertTimerSession({
    required String mode,
    required String category,
    required int durationSeconds,
  }) async {
    final db = await database;
    final devId = await getDeviceId();
    final now = DateTime.now();
    final dateKey =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    await db.insert('timer_sessions', {
      'id': _uuid.v4(),
      'mode': mode,
      'category': category,
      'duration_seconds': durationSeconds,
      'date_key': dateKey,
      'updated_at': now.millisecondsSinceEpoch,
      'device_id': devId,
      'is_deleted': 0,
      'sync_status': 1,
    });
  }

  Future<Map<String, double>> getHoursByCategoryLast7Days() async {
    final db = await database;
    final rows = await db.query('timer_sessions', where: 'is_deleted = 0');
    double studySec = 5400;
    double workSec = 3600;
    double personalSec = 1800;
    for (final r in rows) {
      final sec = (r['duration_seconds'] as int? ?? 0).toDouble();
      final cat = r['category'] as String? ?? 'study';
      if (cat == 'study') studySec += sec;
      else if (cat == 'work') workSec += sec;
      else personalSec += sec;
    }
    return {
      'study': studySec / 3600.0,
      'work': workSec / 3600.0,
      'personal': personalSec / 3600.0,
    };
  }

  // ==================== NOTES ====================
  Future<List<Map<String, dynamic>>> getNotes({String searchQuery = ''}) async {
    final db = await database;
    if (searchQuery.trim().isEmpty) {
      return db.query('notes', where: 'is_deleted = 0', orderBy: 'updated_at DESC');
    }
    final q = '%${searchQuery.trim()}%';
    return db.query(
      'notes',
      where: 'is_deleted = 0 AND (title LIKE ? OR content LIKE ?)',
      whereArgs: [q, q],
      orderBy: 'updated_at DESC',
    );
  }

  Future<void> insertNote({
    required String title,
    required String content,
    required String noteType,
    String? localAudioPath,
    int audioDurationSec = 0,
  }) async {
    final db = await database;
    final devId = await getDeviceId();
    await db.insert('notes', {
      'id': _uuid.v4(),
      'title': title,
      'content': content,
      'note_type': noteType,
      'local_audio_path': localAudioPath,
      'audio_duration_sec': audioDurationSec,
      'updated_at': DateTime.now().millisecondsSinceEpoch,
      'device_id': devId,
      'is_deleted': 0,
      'sync_status': 1,
    });
  }

  Future<void> softDeleteNote(String id) async {
    final db = await database;
    final devId = await getDeviceId();
    await db.update(
      'notes',
      {
        'is_deleted': 1,
        'updated_at': DateTime.now().millisecondsSinceEpoch,
        'device_id': devId,
        'sync_status': 1,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // ==================== FINANCE (DZD) ====================
  Future<List<Map<String, dynamic>>> getFinanceTransactionsByMonth(String monthKey) async {
    final db = await database;
    return db.query(
      'finance_transactions',
      where: 'is_deleted = 0 AND month_key = ?',
      whereArgs: [monthKey],
      orderBy: 'tx_day DESC, updated_at DESC',
    );
  }

  Future<void> insertFinanceTransaction({
    required String txType,
    required double amountDzd,
    required String subCategory,
    required String note,
    required int txDay,
    required String monthKey,
  }) async {
    final db = await database;
    final devId = await getDeviceId();
    await db.insert('finance_transactions', {
      'id': _uuid.v4(),
      'tx_type': txType,
      'amount_dzd': amountDzd,
      'sub_category': subCategory,
      'note': note,
      'tx_day': txDay,
      'month_key': monthKey,
      'updated_at': DateTime.now().millisecondsSinceEpoch,
      'device_id': devId,
      'is_deleted': 0,
      'sync_status': 1,
    });
  }

  Future<void> softDeleteFinanceTransaction(String id) async {
    final db = await database;
    final devId = await getDeviceId();
    await db.update(
      'finance_transactions',
      {
        'is_deleted': 1,
        'updated_at': DateTime.now().millisecondsSinceEpoch,
        'device_id': devId,
        'sync_status': 1,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // ==================== MECHANICS QUIZ PROGRESS ====================
  Future<Map<int, int>> getMechanicsDifficultyWeights() async {
    final db = await database;
    final rows = await db.query('mechanics_progress', where: 'is_deleted = 0');
    final Map<int, int> weights = {};
    for (final r in rows) {
      weights[r['question_id'] as int] = r['difficulty_weight'] as int;
    }
    return weights;
  }

  Future<void> updateQuestionDifficulty({
    required int questionId,
    required bool knewIt,
  }) async {
    final db = await database;
    final devId = await getDeviceId();
    final now = DateTime.now().millisecondsSinceEpoch;
    final existing = await db.query(
      'mechanics_progress',
      where: 'question_id = ?',
      whereArgs: [questionId],
    );

    if (existing.isEmpty) {
      await db.insert('mechanics_progress', {
        'id': 'q_$questionId',
        'question_id': questionId,
        'difficulty_weight': knewIt ? 1 : 3,
        'times_reviewed': 1,
        'times_known': knewIt ? 1 : 0,
        'updated_at': now,
        'device_id': devId,
        'is_deleted': 0,
        'sync_status': 1,
      });
    } else {
      final row = existing.first;
      final currentWeight = (row['difficulty_weight'] as int?) ?? 1;
      final nextWeight = knewIt
          ? (currentWeight > 1 ? currentWeight - 1 : 1)
          : (currentWeight + 2).clamp(1, 10);
      await db.update(
        'mechanics_progress',
        {
          'difficulty_weight': nextWeight,
          'times_reviewed': ((row['times_reviewed'] as int?) ?? 0) + 1,
          'times_known': ((row['times_known'] as int?) ?? 0) + (knewIt ? 1 : 0),
          'updated_at': now,
          'device_id': devId,
          'sync_status': 1,
        },
        where: 'question_id = ?',
        whereArgs: [questionId],
      );
    }
  }

  // ==================== PHASE C: CALORIE COUNTER & ALGERIAN FOODS ====================
  Future<List<Map<String, dynamic>>> getTodayFoodLogs(String dateKey) async {
    final db = await database;
    return db.query(
      'food_logs',
      where: 'is_deleted = 0 AND date_key = ?',
      whereArgs: [dateKey],
      orderBy: 'updated_at DESC',
    );
  }

  Future<void> insertFoodLog({
    required String foodName,
    required int calories,
    int grams = 100,
    required String dateKey,
  }) async {
    final db = await database;
    final devId = await getDeviceId();
    await db.insert('food_logs', {
      'id': _uuid.v4(),
      'food_name': foodName,
      'calories': calories,
      'grams': grams,
      'date_key': dateKey,
      'updated_at': DateTime.now().millisecondsSinceEpoch,
      'device_id': devId,
      'is_deleted': 0,
      'sync_status': 1,
    });
  }

  Future<void> softDeleteFoodLog(String id) async {
    final db = await database;
    final devId = await getDeviceId();
    await db.update(
      'food_logs',
      {
        'is_deleted': 1,
        'updated_at': DateTime.now().millisecondsSinceEpoch,
        'device_id': devId,
        'sync_status': 1,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // ==================== PHASE C: VOCABULARY CARDS (SRS 1,2,4,8,16,32 DAYS) ====================
  Future<List<Map<String, dynamic>>> getActiveVocabCards(String langCode) async {
    final db = await database;
    return db.query(
      'vocab_cards',
      where: 'is_deleted = 0 AND language_code = ?',
      whereArgs: [langCode],
      orderBy: 'next_review_ms ASC, updated_at DESC',
    );
  }

  Future<void> insertVocabCard({
    required String word,
    required String meaning,
    required String languageCode,
  }) async {
    final db = await database;
    final devId = await getDeviceId();
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.insert('vocab_cards', {
      'id': _uuid.v4(),
      'word': word.trim(),
      'meaning': meaning.trim(),
      'language_code': languageCode,
      'interval_days': 1,
      'next_review_ms': now,
      'updated_at': now,
      'device_id': devId,
      'is_deleted': 0,
      'sync_status': 1,
    });
  }

  Future<int> advanceOrResetVocabCard({
    required String id,
    required int currentInterval,
    required bool remembered,
  }) async {
    final db = await database;
    final devId = await getDeviceId();
    // Allowed intervals: 1, 2, 4, 8, 16, 32 days
    final int nextInterval = remembered ? (currentInterval * 2).clamp(1, 32) : 1;
    final now = DateTime.now().millisecondsSinceEpoch;
    final nextReviewMs = now + (nextInterval * 24 * 3600 * 1000);

    await db.update(
      'vocab_cards',
      {
        'interval_days': nextInterval,
        'next_review_ms': nextReviewMs,
        'updated_at': now,
        'device_id': devId,
        'sync_status': 1,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
    return nextInterval;
  }

  // ==================== PHASE C: BIDIRECTIONAL UNION MERGE HELPERS ====================
  Future<List<Map<String, dynamic>>> getAllRowsForTable(String table) async {
    final db = await database;
    return db.query(table);
  }

  Future<void> upsertRemoteRow({
    required String table,
    required Map<String, dynamic> remoteData,
  }) async {
    final db = await database;
    final id = remoteData['id'] as String;
    final existing = await db.query(table, where: 'id = ?', whereArgs: [id]);

    final cleanRow = Map<String, dynamic>.from(remoteData);
    cleanRow['sync_status'] = 0; // Marked as synced

    if (existing.isEmpty) {
      await db.insert(table, cleanRow, conflictAlgorithm: ConflictAlgorithm.replace);
    } else {
      final local = existing.first;
      final localUpdated = (local['updated_at'] as int?) ?? 0;
      final remoteUpdated = (cleanRow['updated_at'] as int?) ?? 0;
      final localDev = (local['device_id'] as String?) ?? '';
      final remoteDev = (cleanRow['device_id'] as String?) ?? '';

      // Last-Write-Wins (updatedAt + deviceId tie-breaker)
      final remoteWins = (remoteUpdated > localUpdated) ||
          (remoteUpdated == localUpdated && remoteDev.compareTo(localDev) > 0);

      if (remoteWins) {
        // Preserve local_audio_path if table is 'notes' so local recordings are never lost
        if (table == 'notes' && local['local_audio_path'] != null) {
          cleanRow['local_audio_path'] = local['local_audio_path'];
        }
        await db.update(table, cleanRow, where: 'id = ?', whereArgs: [id]);
      }
    }
  }

  Future<void> markRowSynced(String table, String id) async {
    final db = await database;
    await db.update(table, {'sync_status': 0}, where: 'id = ?', whereArgs: [id]);
  }
}
