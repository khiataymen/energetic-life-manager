import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../../core/database/local_database.dart';

class LanguageSrsScreen extends StatefulWidget {
  final bool isArabic;

  const LanguageSrsScreen({super.key, required this.isArabic});

  @override
  State<LanguageSrsScreen> createState() => _LanguageSrsScreenState();
}

class _LanguageSrsScreenState extends State<LanguageSrsScreen> {
  final FlutterTts _tts = FlutterTts();
  String _selectedLanguage = 'en-US'; // Default English as requested by user
  List<Map<String, dynamic>> _cards = [];
  int _activeIndex = 0;
  bool _revealMeaning = false;

  final List<Map<String, String>> _wordOfTheDayPool = const [
    {'w': 'Resilience', 'm': 'المرونة والقدرة على التحمل'},
    {'w': 'Adiabatic', 'm': 'كظيم (نظام معزول حراريًا لا يتبادل حرارة)'},
    {'w': 'Steady-State', 'm': 'النظام المستقر (لا يتغير مع الزمن)'},
    {'w': 'Optimization', 'm': 'الاستمثال / تحسين الأداء إلى الحد الأقصى'},
  ];

  @override
  void initState() {
    super.initState();
    _loadCards();
  }

  @override
  void dispose() {
    _tts.stop();
    super.dispose();
  }

  Future<void> _loadCards() async {
    final rows = await LocalDatabase.instance.getActiveVocabCards(_selectedLanguage);
    if (!mounted) return;
    setState(() {
      _cards = rows;
      if (_activeIndex >= _cards.length) _activeIndex = 0;
      _revealMeaning = false;
    });
  }

  Future<void> _speakWord(String text) async {
    await _tts.setLanguage(_selectedLanguage);
    await _tts.setSpeechRate(0.45);
    await _tts.speak(text);
  }

  Future<void> _gradeCurrentCard(bool remembered) async {
    if (_cards.isEmpty) return;
    final card = _cards[_activeIndex];
    final nextInterval = await LocalDatabase.instance.advanceOrResetVocabCard(
      id: card['id'] as String,
      currentInterval: (card['interval_days'] as int?) ?? 1,
      remembered: remembered,
    );
    await _loadCards();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(widget.isArabic
            ? 'تمت جدولة البطاقة للمراجعة بعد $nextInterval يوم'
            : 'Scheduled next review in $nextInterval day(s)'),
      ),
    );
  }

  void _showBatchAddDialog() {
    final ar = widget.isArabic;
    final batchCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ar
            ? '➕ إضافة كلمات فردية أو دفعة واحدة (كلمة = معنى)'
            : '➕ Batch Add Words (word = meaning)'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              ar
                  ? 'اكتب كل كلمة في سطر بصيغة: كلمة = معنى'
                  : 'Enter one per line using: word = meaning',
              style: const TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: batchCtrl,
              maxLines: 5,
              decoration: InputDecoration(
                hintText: 'Turbine = عنفة
Efficiency = مردود طاقوي
Flow rate = معدل التدفق',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(ar ? 'إلغاء' : 'Cancel')),
          FilledButton(
            onPressed: () async {
              final lines = batchCtrl.text.split('
');
              int count = 0;
              for (final line in lines) {
                final parts = line.split('=');
                if (parts.length >= 2) {
                  final word = parts[0].trim();
                  final meaning = parts.sublist(1).join('=').trim();
                  if (word.isNotEmpty && meaning.isNotEmpty) {
                    await LocalDatabase.instance.insertVocabCard(
                      word: word,
                      meaning: meaning,
                      languageCode: _selectedLanguage,
                    );
                    count++;
                  }
                }
              }
              await _loadCards();
              if (ctx.mounted) Navigator.pop(ctx);
              if (mounted && count > 0) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(ar
                        ? 'تمت إضافة $count بطاقة جديدة للمراجعة المتباعدة'
                        : 'Added $count new SRS cards'),
                  ),
                );
              }
            },
            child: Text(ar ? 'حفظ الدفعة' : 'Save Batch'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ar = widget.isArabic;
    final wotd = _wordOfTheDayPool[DateTime.now().day % _wordOfTheDayPool.length];
    final currentCard = _cards.isNotEmpty ? _cards[_activeIndex % _cards.length] : null;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Language Selector & Batch Add Button
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            DropdownButton<String>(
              value: _selectedLanguage,
              items: [
                DropdownMenuItem(
                  value: 'en-US',
                  child: Text(ar ? '🇬🇧 الإنجليزية (الافتراضية)' : '🇬🇧 English (Default)'),
                ),
                DropdownMenuItem(
                  value: 'fr-FR',
                  child: Text(ar ? '🇫🇷 الفرنسية' : '🇫🇷 French'),
                ),
                DropdownMenuItem(
                  value: 'de-DE',
                  child: Text(ar ? '🇩🇪 الألمانية' : '🇩🇪 German'),
                ),
              ],
              onChanged: (v) {
                setState(() => _selectedLanguage = v ?? 'en-US');
                _loadCards();
              },
            ),
            FilledButton.icon(
              onPressed: _showBatchAddDialog,
              icon: const Icon(Icons.playlist_add),
              label: Text(ar ? 'إضافة (كلمة = معنى)' : 'Batch Add'),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Word of the Day Card
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.blueAccent.withOpacity(0.12),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.blueAccent.withOpacity(0.35)),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      ar ? '🌟 كلمة اليوم (Word of the Day)' : '🌟 Word of the Day',
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${wotd['w']} = ${wotd['m']}',
                      style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
                    ),
                  ],
                ),
              ),
              IconButton.filledTonal(
                onPressed: () => _speakWord(wotd['w']!),
                icon: const Icon(Icons.volume_up),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // Spaced Repetition Card (1, 2, 4, 8, 16, 32 days)
        if (currentCard == null)
          Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Text(ar ? 'لا توجد بطاقات بعد — أضف دفعة كلمات للبدء!' : 'No cards yet!'),
            ),
          )
        else
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Chip(
                        label: Text(
                          ar
                              ? 'فترة التكرار: ${currentCard['interval_days']} يوم'
                              : 'Interval: ${currentCard['interval_days']}d (1..32d)',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
                        ),
                      ),
                      Text(
                        '${_activeIndex + 1} / ${_cards.length}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    currentCard['word'] as String,
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 10),
                  IconButton.outlined(
                    onPressed: () => _speakWord(currentCard['word'] as String),
                    icon: const Icon(Icons.volume_up),
                  ),
                  const SizedBox(height: 12),
                  if (_revealMeaning)
                    Text(
                      currentCard['meaning'] as String,
                      style: const TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                      textAlign: TextAlign.center,
                    )
                  else
                    OutlinedButton.icon(
                      onPressed: () => setState(() => _revealMeaning = true),
                      icon: const Icon(Icons.visibility_outlined),
                      label: Text(ar ? 'إظهار المعنى' : 'Reveal Meaning'),
                    ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.tonalIcon(
                          onPressed: () => _gradeCurrentCard(false),
                          icon: const Icon(Icons.refresh, color: Colors.redAccent),
                          label: Text(ar ? 'نسيتها (إلى 1 يوم)' : 'Forgot (Reset 1d)'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton.icon(
                          style: FilledButton.styleFrom(backgroundColor: Colors.green),
                          onPressed: () => _gradeCurrentCard(true),
                          icon: const Icon(Icons.check),
                          label: Text(ar ? 'تذكرتها (×2 يوم)' : 'Remembered (×2d)'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}
