class AlgerianFoodItem {
  final String nameAr;
  final String nameEn;
  final int kcalPerPortion;
  final String portionDesc;

  const AlgerianFoodItem({
    required this.nameAr,
    required this.nameEn,
    required this.kcalPerPortion,
    required this.portionDesc,
  });
}

const List<AlgerianFoodItem> kAlgerianFoodsDatabase = [
  AlgerianFoodItem(
    nameAr: 'كسكس باللحم والخضر',
    nameEn: 'Algerian Couscous with Meat & Veggies',
    kcalPerPortion: 620,
    portionDesc: 'صحن متوسط (350g)',
  ),
  AlgerianFoodItem(
    nameAr: 'رشتة عاصمية بالدجاج',
    nameEn: 'Algiers Rechta with Chicken',
    kcalPerPortion: 580,
    portionDesc: 'صحن متوسط (320g)',
  ),
  AlgerianFoodItem(
    nameAr: 'شخشوخة بسكرية / قسنطينية',
    nameEn: 'Chakhchoukha',
    kcalPerPortion: 690,
    portionDesc: 'صحن متوسط (350g)',
  ),
  AlgerianFoodItem(
    nameAr: 'محاجب حارة (مهجّبة)',
    nameEn: 'Mhadjeb (1 piece)',
    kcalPerPortion: 290,
    portionDesc: 'قطعة واحدة (130g)',
  ),
  AlgerianFoodItem(
    nameAr: 'قرنطيطة (كاران بالحمص والبيض)',
    nameEn: 'Garantita / Karantika',
    kcalPerPortion: 410,
    portionDesc: 'حصة في خبز / صحن (220g)',
  ),
  AlgerianFoodItem(
    nameAr: 'بوراك بالبطاطا واللحم المفروم',
    nameEn: 'Algerian Bourek (1 roll)',
    kcalPerPortion: 210,
    portionDesc: 'حبة واحدة مقلية (85g)',
  ),
  AlgerianFoodItem(
    nameAr: 'طاجين زيتون بالدجاج',
    nameEn: 'Tajine Zitoune',
    kcalPerPortion: 460,
    portionDesc: 'حصة واحدة (260g)',
  ),
  AlgerianFoodItem(
    nameAr: 'تمر دقلة نور جزائرية (ورقلة/طولقة)',
    nameEn: 'Deglet Nour Dates (3 dates)',
    kcalPerPortion: 85,
    portionDesc: '3 تمرات (35g)',
  ),
  AlgerianFoodItem(
    nameAr: 'مقروط بالتمر والعسل',
    nameEn: 'Makrout with Dates & Honey',
    kcalPerPortion: 240,
    portionDesc: 'قطعة واحدة (75g)',
  ),
  AlgerianFoodItem(
    nameAr: 'شوربة فريك باللحم',
    nameEn: 'Chorba Frik',
    kcalPerPortion: 280,
    portionDesc: 'غرفية متوسطة (250ml)',
  ),
  AlgerianFoodItem(
    nameAr: 'لوبيا / عدس جزائري',
    nameEn: 'Algerian Loubia / Lentils Stew',
    kcalPerPortion: 390,
    portionDesc: 'صحن متوسط (300g)',
  ),
  AlgerianFoodItem(
    nameAr: 'كسرة / مطلوع جزائري',
    nameEn: 'Kesra / Matlouh Flatbread',
    kcalPerPortion: 230,
    portionDesc: 'ربع خبزة (90g)',
  ),
];
