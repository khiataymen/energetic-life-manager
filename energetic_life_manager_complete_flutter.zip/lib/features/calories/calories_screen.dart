import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../core/database/local_database.dart';
import 'algerian_foods_data.dart';

class CaloriesScreen extends StatefulWidget {
  final bool isArabic;

  const CaloriesScreen({super.key, required this.isArabic});

  @override
  State<CaloriesScreen> createState() => _CaloriesScreenState();
}

class _CaloriesScreenState extends State<CaloriesScreen> {
  final TextEditingController _searchCtrl = TextEditingController();
  List<Map<String, dynamic>> _todayLogs = [];
  List<Map<String, dynamic>> _onlineResults = [];
  bool _searchingOnline = false;
  int _dailyGoal = 2600;

  String get _todayKey => DateTime.now().toIso8601String().substring(0, 10);

  @override
  void initState() {
    super.initState();
    _loadLogs();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadLogs() async {
    final rows = await LocalDatabase.instance.getTodayFoodLogs(_todayKey);
    if (!mounted) return;
    setState(() => _todayLogs = rows);
  }

  Future<void> _searchOpenFoodFacts() async {
    final q = _searchCtrl.text.trim();
    if (q.isEmpty) return;
    setState(() => _searchingOnline = true);
    try {
      final uri = Uri.parse(
        'https://world.openfoodfacts.org/cgi/search.pl?search_terms=${Uri.encodeComponent(q)}&search_simple=1&action=process&json=1&page_size=6',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final products = (data['products'] as List<dynamic>? ?? []);
        final parsed = <Map<String, dynamic>>[];
        for (final p in products) {
          final map = p as Map<String, dynamic>;
          final name = (map['product_name'] as String?)?.trim() ?? '';
          final nutriments = map['nutriments'] as Map<String, dynamic>? ?? {};
          final kcal = (nutriments['energy-kcal_100g'] as num?)?.round() ?? 0;
          if (name.isNotEmpty && kcal > 0) {
            parsed.add({'name': name, 'kcal': kcal});
          }
        }
        if (mounted) setState(() => _onlineResults = parsed);
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(widget.isArabic
                ? 'لا يوجد اتصال بالإنترنت — استخدم قاعدة الأكلات الجزائرية المحلية'
                : 'Offline — using local Algerian foods database'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _searchingOnline = false);
    }
  }

  void _showManualFoodDialog() {
    final ar = widget.isArabic;
    final nameCtrl = TextEditingController();
    final calCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ar ? '🍲 إضافة وجبة يدويًا' : '🍲 Add Custom Meal'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              decoration: InputDecoration(labelText: ar ? 'اسم الأكلة' : 'Food Name'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: calCtrl,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: ar ? 'السعرات (kcal)' : 'Calories (kcal)'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(ar ? 'إلغاء' : 'Cancel')),
          FilledButton(
            onPressed: () async {
              final kcal = int.tryParse(calCtrl.text.trim()) ?? 0;
              if (nameCtrl.text.trim().isEmpty || kcal <= 0) return;
              await LocalDatabase.instance.insertFoodLog(
                foodName: nameCtrl.text.trim(),
                calories: kcal,
                dateKey: _todayKey,
              );
              await _loadLogs();
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: Text(ar ? 'إضافة' : 'Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ar = widget.isArabic;
    final totalCalories =
        _todayLogs.fold<int>(0, (sum, item) => sum + ((item['calories'] as int?) ?? 0));
    final progress = (totalCalories / _dailyGoal).clamp(0.0, 1.0);
    final query = _searchCtrl.text.trim().toLowerCase();

    final localMatches = kAlgerianFoodsDatabase.where((f) {
      return f.nameAr.toLowerCase().contains(query) ||
          f.nameEn.toLowerCase().contains(query);
    }).toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Approximation Disclaimer Banner
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.amber.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.amber.withOpacity(0.4)),
          ),
          child: Row(
            children: [
              const Icon(Icons.info_outline, color: Colors.amber, size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  ar
                      ? 'تنبيه: القيم الحرارية للأكلات الجزائرية الشعبية تقريبية وتختلف باختلاف المقادير وطريقة التحضير.'
                      : 'Note: Nutritional values for traditional Algerian dishes are approximate.',
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // Daily Calorie Progress Card
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      ar ? '🔥 استهلاك السعرات اليوم' : '🔥 Today’s Calories',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                    Text(
                      '$totalCalories / $_dailyGoal kcal',
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        color: Colors.deepOrange,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                LinearProgressIndicator(
                  value: progress,
                  minHeight: 10,
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.deepOrange,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),

        // Search Local Algerian Database + Open Food Facts Online Button
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _searchCtrl,
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search),
                  hintText: ar
                      ? 'ابحث (كسكس، رشتة، شخشوخة، محاجب، قرنطيطة، بوراك...)'
                      : 'Search Algerian foods or OpenFoodFacts...',
                  isDense: true,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                ),
              ),
            ),
            const SizedBox(width: 6),
            IconButton.filledTonal(
              tooltip: 'Open Food Facts API',
              onPressed: _searchingOnline ? null : _searchOpenFoodFacts,
              icon: _searchingOnline
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.cloud_download_outlined),
            ),
            const SizedBox(width: 6),
            FilledButton(
              onPressed: _showManualFoodDialog,
              child: Text(ar ? '+ يدوي' : '+ Custom'),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Quick Add Chips from Local Algerian Foods Database
        Text(
          ar ? '🇩🇿 قاعدة الأكلات الجزائرية المحلية (إضافة سريعة):' : '🇩🇿 Local Algerian Foods Database:',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: localMatches.map((food) {
            final label = ar ? food.nameAr : food.nameEn;
            return ActionChip(
              avatar: const Icon(Icons.add_circle_outline, size: 18, color: Colors.deepOrange),
              label: Text('$label (${food.kcalPerPortion} kcal)', style: const TextStyle(fontSize: 11)),
              onPressed: () async {
                await LocalDatabase.instance.insertFoodLog(
                  foodName: label,
                  calories: food.kcalPerPortion,
                  dateKey: _todayKey,
                );
                _loadLogs();
              },
            );
          }).toList(),
        ),

        if (_onlineResults.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text(
            ar ? '🌐 نتائج Open Food Facts عبر الإنترنت:' : '🌐 Open Food Facts Results:',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
          ),
          const SizedBox(height: 6),
          ..._onlineResults.map((item) => ListTile(
                dense: true,
                title: Text(item['name'] as String),
                trailing: Text('${item['kcal']} kcal/100g'),
                onTap: () async {
                  await LocalDatabase.instance.insertFoodLog(
                    foodName: item['name'] as String,
                    calories: item['kcal'] as int,
                    dateKey: _todayKey,
                  );
                  _loadLogs();
                },
              )),
        ],

        const SizedBox(height: 16),
        Text(
          ar ? '📋 وجباتك المسجلة اليوم' : '📋 Today’s Logged Meals',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
        ),
        const SizedBox(height: 8),
        ..._todayLogs.map((log) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: const Icon(Icons.restaurant_menu, color: Colors.deepOrange),
                title: Text(
                  log['food_name'] as String,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${log['calories']} kcal',
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        color: Colors.deepOrange,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                      onPressed: () async {
                        await LocalDatabase.instance.softDeleteFoodLog(log['id'] as String);
                        _loadLogs();
                      },
                    ),
                  ],
                ),
              ),
            )),
      ],
    );
  }
}
