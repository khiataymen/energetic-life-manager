import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NotificationService {
  static final NotificationService instance = NotificationService._();
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static const MethodChannel _batteryChannel =
      MethodChannel('dz.energetic.lifemanager/battery');

  NotificationService._();

  Future<void> init() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: androidInit);
    await _plugin.initialize(settings);

    const androidChannel = AndroidNotificationChannel(
      'energetic_high_channel',
      'التنبيهات الدقيقة والمهام (High Priority)',
      description: 'تنبيهات المهام والمؤقت والجدول الدراسي والعمل وتمارين الميكانيك',
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
    );

    final androidImplementation =
        _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidImplementation?.createNotificationChannel(androidChannel);
    await androidImplementation?.requestNotificationsPermission();
    await androidImplementation?.requestExactAlarmsPermission();
  }

  Future<bool> isWithinQuietHours() async {
    final prefs = await SharedPreferences.getInstance();
    final enabled = prefs.getBool('quiet_enabled') ?? true;
    if (!enabled) return false;
    final startHour = prefs.getInt('quiet_start_h') ?? 23;
    final endHour = prefs.getInt('quiet_end_h') ?? 6;
    final nowH = DateTime.now().hour;
    if (startHour > endHour) {
      return nowH >= startHour || nowH < endHour;
    } else {
      return nowH >= startHour && nowH < endHour;
    }
  }

  Future<void> showImmediateNotification({
    required int id,
    required String title,
    required String body,
    bool isRoutine = false,
  }) async {
    if (isRoutine && await isWithinQuietHours()) {
      return;
    }

    const androidDetails = AndroidNotificationDetails(
      'energetic_high_channel',
      'التنبيهات الدقيقة والمهام (High Priority)',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
    );
    await _plugin.show(id, title, body, const NotificationDetails(android: androidDetails));
  }

  Future<void> requestIgnoreBatteryOptimizations() async {
    try {
      await _batteryChannel.invokeMethod('requestIgnoreBatteryOptimizations');
    } catch (_) {}
  }

  Future<void> openExactAlarmSettings() async {
    try {
      await _batteryChannel.invokeMethod('openExactAlarmSettings');
    } catch (_) {}
  }
}
