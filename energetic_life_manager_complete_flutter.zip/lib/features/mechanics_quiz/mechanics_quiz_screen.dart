import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/database/local_database.dart';
import 'mechanics_questions_data.dart';

class MechanicsQuizScreen extends StatefulWidget {
  final bool isArabic;

  const MechanicsQuizScreen({super.key, required this.isArabic});

  @override
  State<MechanicsQuizScreen> createState() => _MechanicsQuizScreenState();
}

class _MechanicsQuizScreenState extends State<MechanicsQuizScreen> {
  String _selectedTopic = 'all';
  int _currentIndex = 0;
  bool _showAnswer = false;
  Map<int, int> _weights = {};
  int _dailyGoal = 10;
  int _completedToday = 0;

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final w = await LocalDatabase.instance.getMechanicsDifficultyWeights();
    final prefs = await SharedPreferences.getInstance();
    final todayKey = DateTime.now().toIso8601String().substring(0, 10);
    final savedDate = prefs.getString('quiz_date_key') ?? '';
    int count = 0;
    if (savedDate == todayKey) {
      count = prefs.getInt('quiz_completed_today') ?? 0;
    } else {
      await prefs.setString('quiz_date_key', todayKey);
      await prefs.setInt('quiz_completed_today', 0);
    }
    if (!mounted) return;
    setState(() {
      _weights = w;
      _completedToday = count;
    });
  }

  List<MechanicsQuestion> get _filteredQuestions {
    if (_selectedTopic == 'all') return kMechanicsQuestionsBank;
    return kMechanicsQuestionsBank.where((q) => q.topic == _selectedTopic).toList();
  }

  Future<void> _recordAnswer(bool knewIt) async {
    final list = _filteredQuestions;
    if (list.isEmpty) return;
    final currentQ = list[_currentIndex % list.length];
    await LocalDatabase.instance.updateQuestionDifficulty(
      questionId: currentQ.id,
      knewIt: knewIt,
    );

    final prefs = await SharedPreferences.getInstance();
    final nextCount = _completedToday + 1;
    await prefs.setInt('quiz_completed_today', nextCount);

    final updatedWeights = await LocalDatabase.instance.getMechanicsDifficultyWeights();
    if (!mounted) return;
    setState(() {
      _weights = updatedWeights;
      _completedToday = nextCount;
      _showAnswer = false;
      _currentIndex = _pickNextWeightedIndex(list, updatedWeights);
    });
  }

  int _pickNextWeightedIndex(List<MechanicsQuestion> list, Map<int, int> weights) {
    final List<int> pool = [];
    for (int i = 0; i < list.length; i++) {
      final w = weights[list[i].id] ?? 1;
      for (int c = 0; c < w; c++) {
        pool.add(i);
      }
    }
    if (pool.isEmpty) return 0;
    return pool[Random().nextInt(pool.length)];
  }

  @override
  Widget build(BuildContext context) {
    final ar = widget.isArabic;
    final list = _filteredQuestions;
    final currentQ = list[_currentIndex % list.length];
    final weight = _weights[currentQ.id] ?? 1;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Daily Goal Progress Header
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                ar
                    ? '⚙️ تمارين الميكانيك الطاقوية (40 سؤالًا EN/AR/FR)'
                    : '⚙️ Energetic Mechanics Quiz (40 EN/AR/FR Qs)',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
            ),
            Chip(
              label: Text(
                ar
                    ? 'هدف اليوم: $_completedToday / $_dailyGoal'
                    : 'Daily Goal: $_completedToday / $_dailyGoal',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),

        // Topic Filter
        DropdownButtonFormField<String>(
          value: _selectedTopic,
          decoration: InputDecoration(
            labelText: ar ? 'اختر المحور العلمي' : 'Select Topic',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            isDense: true,
          ),
          items: [
            DropdownMenuItem(value: 'all', child: Text(ar ? 'كل المحاور (40 سؤالًا)' : 'All Topics (40 Qs)')),
            DropdownMenuItem(value: 'thermodynamics', child: const Text('Thermodynamics / ثرموديناميك (10)')),
            DropdownMenuItem(value: 'heat_transfer', child: const Text('Heat Transfer / انتقال حراري (10)')),
            DropdownMenuItem(value: 'fluid_mechanics', child: const Text('Fluid Mechanics / ميكانيك الموائع (10)')),
            DropdownMenuItem(value: 'power_cycles', child: const Text('Power Cycles / الدورات الحرارية (10)')),
          ],
          onChanged: (v) {
            setState(() {
              _selectedTopic = v ?? 'all';
              _currentIndex = 0;
              _showAnswer = false;
            });
          },
        ),
        const SizedBox(height: 16),

        // Flashcard
        Card(
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Chip(
                      label: Text(
                        '#${currentQ.id} • ${currentQ.lang} • ${currentQ.topic}',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.amber.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        ar ? 'وزن التكرار: ${weight}x' : 'Repeat Weight: ${weight}x',
                        style: const TextStyle(
                          color: Colors.amber,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Text(
                  currentQ.question,
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, height: 1.4),
                ),
                const SizedBox(height: 16),

                if (_showAnswer)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.green.withOpacity(0.4)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          ar ? '✓ الجواب والصيغة الدقيقة:' : '✓ Exact Formula & Answer:',
                          style: const TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          currentQ.answer,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '📚 ${currentQ.reference}',
                          style: const TextStyle(fontSize: 11, fontStyle: FontStyle.italic),
                        ),
                      ],
                    ),
                  )
                else
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () => setState(() => _showAnswer = true),
                      icon: const Icon(Icons.visibility_outlined),
                      label: Text(ar ? 'إظهار الجواب والصيغة المرجعية' : 'Show Answer & Formula'),
                    ),
                  ),

                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(backgroundColor: Colors.green),
                        onPressed: () => _recordAnswer(true),
                        icon: const Icon(Icons.check),
                        label: Text(ar ? 'عرفتها' : 'Knew It'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
                        onPressed: () => _recordAnswer(false),
                        icon: const Icon(Icons.replay),
                        label: Text(ar ? 'أعدها (صعب)' : 'Repeat (Hard)'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
