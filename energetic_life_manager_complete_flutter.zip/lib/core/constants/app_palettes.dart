import 'package:flutter/material.dart';

class AppPaletteOption {
  final String id;
  final String nameAr;
  final String nameEn;
  final Color primary;

  const AppPaletteOption({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.primary,
  });
}

class AppPalettes {
  static const Color studyBlue = Color(0xFF2563EB);
  static const Color workGreen = Color(0xFF16A34A);
  static const Color personalOrange = Color(0xFFEA580C);

  static const List<AppPaletteOption> palettes = [
    AppPaletteOption(
      id: 'blue',
      nameAr: 'أزرق طاقوي',
      nameEn: 'Energetic Blue',
      primary: Color(0xFF2563EB),
    ),
    AppPaletteOption(
      id: 'emerald',
      nameAr: 'زمردي جزائري',
      nameEn: 'Algerian Emerald',
      primary: Color(0xFF0D9488),
    ),
    AppPaletteOption(
      id: 'violet',
      nameAr: 'بنفسجي ملكي',
      nameEn: 'Royal Violet',
      primary: Color(0xFF7C3AED),
    ),
    AppPaletteOption(
      id: 'crimson',
      nameAr: 'ياقوتي',
      nameEn: 'Crimson Ruby',
      primary: Color(0xFFE11D48),
    ),
    AppPaletteOption(
      id: 'amber',
      nameAr: 'ذهبي صحراوي',
      nameEn: 'Sahara Gold',
      primary: Color(0xFFD97706),
    ),
    AppPaletteOption(
      id: 'ocean',
      nameAr: 'سماوي متوسطي',
      nameEn: 'Mediterranean Cyan',
      primary: Color(0xFF0284C7),
    ),
  ];

  static Color categoryColor(String category) {
    switch (category) {
      case 'study':
        return studyBlue;
      case 'work':
        return workGreen;
      default:
        return personalOrange;
    }
  }

  static String categoryLabel(String category, bool isArabic) {
    if (isArabic) {
      switch (category) {
        case 'study':
          return 'دراسة (ماستر)';
        case 'work':
          return 'عمل (مقهى/خاص)';
        default:
          return 'شخصي وصحة';
      }
    } else {
      switch (category) {
        case 'study':
          return 'Study (M1)';
        case 'work':
          return 'Work (Cyber/Private)';
        default:
          return 'Personal & Health';
      }
    }
  }
}
